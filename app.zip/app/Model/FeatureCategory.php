<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Model\FeatureCategory
 *
 * @method static \Illuminate\Database\Eloquent\Builder|FeatureCategory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|FeatureCategory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|FeatureCategory query()
 * @mixin \Eloquent
 */
class FeatureCategory extends Model
{
    //
}
