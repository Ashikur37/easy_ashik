<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Model\CouponOrder
 *
 * @method static \Illuminate\Database\Eloquent\Builder|CouponOrder newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CouponOrder newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CouponOrder query()
 * @mixin \Eloquent
 */
class CouponOrder extends Model
{
    //
}
