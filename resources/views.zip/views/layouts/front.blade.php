<!doctype html>
<html lang="en">
<head>
    <title>
        @hasSection('title')
@yield('title')-{{ $setting->title }}
@else
        {{ $setting->title }}
@endif
    </title>
    <link rel="icon" href="{{ URL::to('/images/banner/' . $setting->favicon) }}" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
@sectionMissing('meta')
    <meta name="keywords" content="{{ $setting->meta_title }}">
    <meta name="description" content="{{ $setting->meta_description }}">
    <meta property="og:title" content="{{ $setting->meta_title }}" />
    <meta property="og:description" content="{{ $setting->meta_description }}" />
    <meta property="og:image" content="{{ URL::to('/images/banner/' . $setting->header_logo) }}" />
@endif
@yield('meta')
    
    <link rel="stylesheet" href="{{ asset('front/css/vendor/vendor-plugin.css') }}" />  
@yield('pageStyle')
<link rel="stylesheet" href="{{ asset('front/css/core.css') }}" />
    {!! $setting->custom_css !!}
    @if ($setting->is_pixel)
    {!! $setting->facebook_pixel !!}
    @endif
</head>
<body style="--dynamic-color:{{ $setting->theme_color }}">
@include('includes.front.header')
    <div class="d-none" id="site-loader">
        <img alt="loader" class="loader__image" src="{{ asset('images/banner/' . $setting->site_loader) }}">
    </div>
    @yield('content')
    @include('includes.front.footer')
    <div class="product-cart-status" id="aside-cart">
        @include('includes.front.cart')
    </div>
    <div class="dynamic-color-panel">
        <h4>Choose Theme Color</h4>
        <div class="dynamic-color-panel-trigger">
            <i class="ri-settings-4-line"></i>
        </div>
        <div class="color-list">
            <div class="color-item">
                <input value="#0088ff" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#FB0000" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>

            <div class="color-item">
                <input value="#0CF805" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#e1bf08" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#f20ca3" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#10f0f0" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#6800ff" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#0e0e0e" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#ff5400" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#4b0082" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#110af7" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#415f7a" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#6b2a1b" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#760a37" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
            <div class="color-item">
                <input value="#2d8f61" type="radio" name="color" class="product-color theme-color">
                <i class="checked-icon"></i>
            </div>
        </div>
        <h4 class="mt-4">Custom Color</h4>
        <input type="color" id="favcolor" name="favcolor" value="{{ $setting->theme_color }}" class="form-control">
    </div>
    <script src="{{ asset('front/js/vendor/jquery.min.js') }}"></script>
    @yield('pageScripts')
    <script src="{{ asset('front/js/vendor/plugins.js') }}"></script>
    <script src="{{ asset('front/js/core.js') }}"></script>
    <script>
        var mainUrl = "{{ URL::to('/') }}";
        var lng = {!!json_encode($lng) !!}
        var loggedIn = "{{ auth()->check() }}";
        $(function () {
            $(".theme-color").on('click',function(){
               $(document.body).css("--dynamic-color",$(this).val())
            })
            $("#favcolor").on('input',function(){
                $(document.body).css("--dynamic-color",$(this).val())
            })
            @if(Session::has('success'))     
            toastr.success('{{ Session::get('success') }}')
            @endif
            @if(Session::has('error'))
            toastr.error('{{ Session::get('error') }}')
            @endif
        }) 
    </script>
    @if ($setting->is_messenger)
        {!! $setting->messenger !!}
    @endif

    @if ($setting->is_tawk_to)
        {!! $setting->tawk_to !!}
    @endif

    @if ($setting->is_analytic)
        {!! $setting->google_analytic !!}
    @endif
    {!! $setting->custom_js !!}
</body>
</html>
