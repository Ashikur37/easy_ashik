<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Model\Throttle
 *
 * @method static \Illuminate\Database\Eloquent\Builder|Throttle newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Throttle newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Throttle query()
 * @mixin \Eloquent
 */
class Throttle extends Model
{
    //
}
