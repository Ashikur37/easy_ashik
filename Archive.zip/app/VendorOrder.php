<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VendorOrder extends Model
{
    protected $guarded=[];
}
