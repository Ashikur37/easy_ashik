@foreach($values as $value)
<option value="{{$value->id}}">{{$value->value}}</option>
@endforeach