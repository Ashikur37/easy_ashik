<div class="footer">
  <div class="row">
    <div class="col-12">
    &copy; {{date('Y')}} {{$setting->copyright_text}} 
    </div>
  </div>
</div>