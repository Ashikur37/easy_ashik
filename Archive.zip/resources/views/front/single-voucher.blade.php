@extends('layouts.front')

@section('content')
    <div class="container">
        <div class="row my-20">
            <div class="col-md-6 mb-20 prl-10">
                <div class="single-card d-flex">
                    <div class="img-wrap">
                        <img src="{{asset('images/voucher/voucher.png')}}" alt="" class="img-fluid">
                    </div>
                    <div class="content-wrapper">
                        <h2 class="section-title">Meghna Pulp &amp;  Paper Mills Ltd</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-20 prl-10">
                <div class="single-card d-flex">
                    <div class="img-wrap">
                        <img src="{{asset('images/voucher/voucher.png')}}" alt="" class="img-fluid">
                    </div>
                    <div class="content-wrapper">
                        <h2 class="section-title">Meghna Pulp &amp;  Paper Mills Ltd</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-20 prl-10">
                <div class="single-card d-flex">
                    <div class="img-wrap">
                        <img src="{{asset('images/voucher/voucher.png')}}" alt="" class="img-fluid">
                    </div>
                    <div class="content-wrapper">
                        <h2 class="section-title">Meghna Pulp &amp;  Paper Mills Ltd</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-20 prl-10">
                <div class="single-card d-flex">
                    <div class="img-wrap">
                        <img src="{{asset('images/voucher/voucher.png')}}" alt="" class="img-fluid">
                    </div>
                    <div class="content-wrapper">
                        <h2 class="section-title">Meghna Pulp &amp;  Paper Mills Ltd</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-20 prl-10">
                <div class="single-card d-flex">
                    <div class="img-wrap">
                        <img src="{{asset('images/voucher/voucher.png')}}" alt="" class="img-fluid">
                    </div>
                    <div class="content-wrapper">
                        <h2 class="section-title">Meghna Pulp &amp;  Paper Mills Ltd</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-20 prl-10">
                <div class="single-card d-flex">
                    <div class="img-wrap">
                        <img src="{{asset('images/voucher/voucher.png')}}" alt="" class="img-fluid">
                    </div>
                    <div class="content-wrapper">
                        <h2 class="section-title">Meghna Pulp &amp;  Paper Mills Ltd</h2>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-20 prl-10">
                <div class="single-card d-flex">
                    <div class="img-wrap">
                        <img src="{{asset('images/voucher/voucher.png')}}" alt="" class="img-fluid">
                    </div>
                    <div class="content-wrapper">
                        <h2 class="section-title">Meghna Pulp &amp;  Paper Mills Ltd</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-20 prl-10">
                <div class="single-card d-flex">
                    <div class="img-wrap">
                        <img src="{{asset('images/voucher/voucher.png')}}" alt="" class="img-fluid">
                    </div>
                    <div class="content-wrapper">
                        <h2 class="section-title">Meghna Pulp &amp;  Paper Mills Ltd</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection